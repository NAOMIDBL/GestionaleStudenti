<template>
  <div class="footer">
    <hr />
    <div class="container">
      <div class="row justify-content-center">
        <img class="logoBottom" alt="Chico logo" src="../assets/logo.png" />
        <p>
          Copyright &copy; 2021 All Rights Reserved by
          <a>Naomi Di Blasi</a>
        </p>
      </div>
    </div>
  </div>
</template>
